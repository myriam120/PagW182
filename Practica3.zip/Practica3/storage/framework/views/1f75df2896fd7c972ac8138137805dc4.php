<?php $__env->startSection('titulo', 'inicio'); ?>


<?php $__env->startSection('contenido'); ?>

<h1 class="display-1 text-center text-danger mt-5">Home</h1>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PW182\Practica3\resources\views/welcome.blade.php ENDPATH**/ ?>