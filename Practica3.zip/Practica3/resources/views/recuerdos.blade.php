@extends('layouts.plantilla')

@section('titulo', 'Recurdos')

@section('contenido')

<h1 class="display-1 text-center text-danger mt-5"> RECUERDOS </h1>

@include('partials.pagination')


@endsection