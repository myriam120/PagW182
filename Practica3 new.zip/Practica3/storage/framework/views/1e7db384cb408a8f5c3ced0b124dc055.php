

<?php $__env->startSection('titulo', 'Recuerdos'); ?>

<?php $__env->startSection('contenido'); ?>

<?php echo $__env->make('partials.modal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<h1 class="display-1 text-center text-danger mt-5"> RECUERDOS </h1>

<div class="container">

<?php $__currentLoopData = $consulRecuerdos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recuerdo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

    <div class="card w-75 mb-3 mt-5">
    <div class="card-body">
        <h5 class="card-title fw-semibold"><?php echo e($recuerdo->titulo); ?> </h5>
        <p class="card-text fst-italic"><?php echo e($recuerdo->fecha); ?></p>
        <p class="card-text fst-lighter"><?php echo e($recuerdo->recuerdo); ?></p>
        <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#editar">
            Editar
        </button>
        <a href="#" class="btn btn-danger">Borrar</a>
    </div>
    </div>

<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\PW182\Practica3\resources\views/recuerdos.blade.php ENDPATH**/ ?>